#pragma once
//#define DEBUG
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include "ByteReaderHeader.h"